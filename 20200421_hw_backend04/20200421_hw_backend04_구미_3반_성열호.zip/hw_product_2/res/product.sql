use hellotest;

create table `hw_product` (
	`pcode` varchar(20) primary key,
    `pname` varchar(20) not null,
    `price` varchar(20) not null,
    `pdesc` varchar(30) not null
);
insert into hw_product (pcode,pname, price,pdesc) values
(1,'aaa',15000,'not good');