<template>
  <div>
    <div v-if="error">
      {{error}}
    </div>
    <table class="table table-bordered w-50">
      <tr>
        <th>사원 아이디</th>
        <td>{{item.id}}</td>
      </tr>
      <tr>
        <th>이름</th>
        <td>{{item.name}}</td>
      </tr>
      <tr>
        <th>이메일</th>
        <td>{{item.mailid}}</td>
      </tr>
      <tr>
        <th>고용일</th>
        <td>{{getFormatDate(item.start_date)}}</td>
      </tr>
      <tr>
        <th>관리자</th>
        <td>{{item.manager_id}}</td>
      </tr>
      <tr>
        <th>직책</th>
        <td>{{item.title}}</td>
      </tr>
      <tr>
        <th>부서</th>
        <td>{{item.dept_id}}</td>
      </tr>
      <tr>
        <th>월급</th>
        <td>{{item.salary}}</td>
      </tr>
      <tr>
        <th>커미션</th>
        <td>{{item.commission_pct}}</td>
      </tr>
    </table>
    <br />
    <div class="text-center">
      <router-link to="/list" class="btn btn-primary">목록</router-link>
      <router-link :to="'/delete?id=' + item.id" class="btn btn-primary">퇴사</router-link>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import moment from 'moment';

export default {
    name: 'Detail',
    data() {
      return {
        item: {},
        error: ''
      }
    },
    created() {
      const params = new URL(document.location).searchParams;
      axios
      .get(`http://localhost:8097/hrmboot/api/employee/${params.get('id')}`)
      .then((response) => {
        this.item = response.data;
      })
      .catch((error) => {
        console.dir(error);
      });
    },
    methods: {
      getFormatDate(start_date) {
        return moment(new Date(start_date)).format('YYYY.MM.DD');
      }
    }
}
</script>

<style>

</style>