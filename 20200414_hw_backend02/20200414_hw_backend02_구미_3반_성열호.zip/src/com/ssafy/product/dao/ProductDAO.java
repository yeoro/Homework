package com.ssafy.product.dao;

import com.ssafy.product.vo.Product;

public interface ProductDAO {
	
	void insertProduct(Product product) throws Exception;
	
}
