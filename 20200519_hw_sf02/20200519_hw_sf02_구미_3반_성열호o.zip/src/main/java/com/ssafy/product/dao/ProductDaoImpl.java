package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;
import com.ssafy.product.dto.ProductException;
import com.ssafy.product.util.DBUtil;

@Repository("productRepository")
public class ProductDaoImpl implements ProductDao{

	public List<Product> selectAll(){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Product> list = new ArrayList<Product>();
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT * FROM product_hw \n");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				
				list.add(product);
			}
		} catch(Exception e){
			e.printStackTrace();
			throw new ProductException("상품 목록 오류");
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return list;
	}

	public Product select(String id){
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT id, name, price, description FROM product_hw \n");
			sql.append("WHERE id = ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				
				return product;
			}
		}catch(SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 조회 오류");
		}finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return null;
	}

	public int insert(Product product){
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT into product_hw (id, name, price, description) \n");
			sql.append("values ( ?, ?, ?, ? ) \n");
			pstmt = conn.prepareStatement(sql.toString());
			
			int idx = 1;
			pstmt.setString(idx++, product.getId());
			pstmt.setString(idx++, product.getName());
			pstmt.setInt(idx++, product.getPrice());
			pstmt.setString(idx++, product.getDescription());
			
			pstmt.executeUpdate();
			
			return 1;
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 등록 오류");
		}finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	public int update(Product product){
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE product_hw \n");
			sql.append("SET	name = ?, \n");
			sql.append("	price = ?, \n");
			sql.append("	description = ? \n");
			sql.append("WHERE id = ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			
			int idx = 1;
			pstmt.setString(idx++, product.getName());
			pstmt.setInt(idx++, product.getPrice() );
			pstmt.setString(idx++, product.getDescription());
			pstmt.setString(idx++, product.getId());
			pstmt.executeUpdate();
			
			return 1;
		}catch(SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 수정 오류");
		}finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	public int delete(String id){
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("DELETE from product_hw \n");
			sql.append("WHERE id = ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.executeUpdate();
			
			return 1;
			
		}catch(SQLException e) {
			e.printStackTrace();
			throw new ProductException("상품 삭제 오류");
		}finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

}
