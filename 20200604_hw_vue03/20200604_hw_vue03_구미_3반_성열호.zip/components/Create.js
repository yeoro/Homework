export default {
  template: `
  <div>
    <table>
    <tr>
        <td>이름</td>
        <td>
            <input type="text" id="name" ref="name" v-model="name">
        </td>
    </tr>
    <tr>
        <td>이메일</td>
        <td>
            <input type="text" id="email" ref="email" v-model="email">
        </td>
    </tr>
    <tr>
        <td>고용일</td>
        <td>
            <input type="date" id="hiredate" ref="hiredate" v-model="hiredate">
        </td>
    </tr>
    <tr>
        <td>관리자</td>
        <td>
            <select ref="admin" id="admin" v-model="admin">
                <option value="1">관리자1</option>
                <option value="2">관리자2</option>
                <option value="3">관리자3</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>직책</td>
        <td>
            <select ref="title" id="title" v-model="title">
                <option value="사장">사장</option>
                <option value="기획부장">기획부장</option>
                <option value="영업부장">영업부장</option>
                <option value="총무부장">총무부장</option>
                <option value="인사부장">인사부장</option>
                <option value="과장">과장</option>
                <option value="영업대표이사">영업대표이사</option>
                <option value="사원">사원</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>부서</td>
        <td>
            <select ref="dept" id="dept" v-model="dept">
                <option value="기획부">기획부</option>
                <option value="영업부">영업부</option>
                <option value="총무부">총무부</option>
                <option value="인사부">인사부</option>
            </select>
        </td>
    </tr>
    <tr>
        <td>월급</td>
        <td>
            <input type="text" id="salary" ref="salary" v-model="salary">
        </td>
    </tr>
    <tr>
        <td>커미션</td>
        <td>
            <input type="commission" id="commission" ref="commission" v-model="commission">
        </td>
    </tr>
</table>
<button @click="checkHandler">사원추가</button>
<button @click="moveList">사원목록</button>
</div>
    `,
  data() {
    return {
      id: '',
      name: '',
      email: '',
      hiredate: '',
      admin: '',
      title: '',
      dept: '',
      salary: '',
      commission: '',
    };
  },
  methods: {
    checkHandler(){
        let err = true;
        let msg = '';
        
        !this.name && (msg = '이름을 입력해주세요.', err = false);
        err && !this.email && (msg = '이메일을 입력해주세요.', err = false);
        err && !this.hiredate && (msg = '고용일을 입력해주세요.', err = false);
        err && !this.admin && (msg = '관리자를 입력해주세요.', err = false);
        err && !this.title && (msg = '직책을 입력해주세요.', err = false);
        err && !this.dept && (msg = '부서를 입력해주세요.', err = false);
        err && !this.salary && (msg = '월급을 입력해주세요.', err = false);
        err && !this.commission && (msg = '커미션을 입력해주세요.', err = false);
        
        if(!err){
            alert(msg);
        } else{
            this.createHandler();
        }
    },
    createHandler(){
        const emp = localStorage.getItem("emp");

        let newEmp = {
            sequence: 0,
            items: []
        };

        if(emp){
            newEmp = JSON.parse(emp);
        }

        newEmp.sequence += 1;

        newEmp.items.push({
            id: newEmp.sequence,
            name: this.name,
            email: this.email,
            hiredate: this.hiredate,
            admin: this.admin,
            title: this.title,
            dept: this.dept,
            salary: this.salary,
            commission: this.commission
        })

        localStorage.setItem("emp", JSON.stringify(newEmp));
        alert('등록이 완료되었습니다.');
        this.moveList();
    },

    moveList(){
        location.href = "./list.html";
    }
},
};
