import Vue from "vue";
import VueRouter from "vue-router";

import Create from '@/components/Create.vue';
import List from '@/components/List.vue';
import Index from '@/components/Index.vue';
import Detail from '@/components/Detail.vue';
import Delete from '@/components/Delete.vue'

Vue.use(VueRouter);

export default new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'index',
            component: Index
        },
        {
            path: '/list',
            name: 'list',
            component: List
        },
        {
            path: '/create',
            name: 'create',
            component: Create
        },
        {
          path: '/detail',
          name: 'detail',
          component: Detail
        },
        {
          path: '/delete',
          name: 'delete',
          component: Delete
        }
    ]
})