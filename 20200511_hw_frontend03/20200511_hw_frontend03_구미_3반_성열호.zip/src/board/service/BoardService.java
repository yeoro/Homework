package board.service;

import java.util.List;

import board.vo.Board;

public interface BoardService {
	
	List<Board> list() throws Exception;

	Board detail(int no) throws Exception;
	
	void write(Board board) throws Exception;
	
	void delete(int no) throws Exception;
}
