package com.ssafy.product.dao;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductDao {

	List<Product> selectAll();
	
	Product select(String id);
	
	int insert(Product product);
	
	int update(Product product);
	
	int delete(String id);
}
