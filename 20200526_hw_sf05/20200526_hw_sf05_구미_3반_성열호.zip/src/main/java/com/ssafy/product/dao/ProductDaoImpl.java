package com.ssafy.product.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.product.dto.Product;

@Repository("productRepository")
public class ProductDaoImpl implements ProductDao{

	private static final String NS = "com.ssafy.product.dao.ProductDao.";
	@Autowired
	private SqlSession sqlSession;//sql문 호출하는 객체!!
	
	public void insert(Product product){
		sqlSession.insert(NS + "insertProduct", product);
	}
	public void update(Product product){
		sqlSession.update(NS + "updateProduct", product);
	}
		
	public void delete(String id){
		sqlSession.delete(NS + "removeProduct", id);
	}

	public Product select(String id){
		return sqlSession.selectOne(NS + "searchProduct", id);
	}
	
	public List<Product> selectAll() {
		return sqlSession.selectList(NS + "selectAll");
	}

}
