package com.ssafy.product.service;

import com.ssafy.product.vo.MemberDto;
import com.ssafy.product.dao.LoginDao;
import com.ssafy.product.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {

	LoginDao loginDao;
	
	public LoginServiceImpl() {
	   loginDao = new LoginDaoImpl();
	}

	@Override
	public MemberDto login(String userid, String userpwd) throws Exception {
		if (userid == null || userpwd == null) {
			throw new Exception();
	    }
	    return loginDao.login(userid, userpwd);
	}

}
