package com.ssafy.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductRestController {
	@Autowired 
	ProductService service;
	
	@GetMapping("list") 
	public ResponseEntity<List<Product>> bookList(Model model) {
		return new ResponseEntity<>(service.selectAll(), HttpStatus.OK);
	}
	
	@GetMapping("searchProduct")
	public ResponseEntity<Product> searchBook(String id) {
		return new ResponseEntity<>(service.select(id), HttpStatus.OK);
	}
	
	@PostMapping("insertProduct")
	public ResponseEntity<String> insertBook(Product product) {
		service.insert(product);
		return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
	}
	
	@PostMapping("updateProduct")
	public ResponseEntity<String> updateBook(Product product) {
		 service.update(product);
		 return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
	}
	
	@GetMapping("removeProduct")
	public ResponseEntity<String> removeBook(String id) {
		service.delete(id);
		return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
	}
}
