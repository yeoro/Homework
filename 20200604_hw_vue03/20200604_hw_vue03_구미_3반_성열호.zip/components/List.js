export default {
  template: `
    
    <div v-if="items.length">
      <div>
        <input type="text" v-model="search" />
        <button @click="searchEmp(search)">검색</button>
      </div>
      <table class="table table-bordered table-condensed">
        <colgroup>
          <col :style="{width: '10%'}" />
          <col :style="{width: '50%'}" />
          <col :style="{width: '15%'}" />
          <col :style="{width: '25%'}" />
        </colgroup>
        <tr>
          <th>사원 아이디</th>
          <th>사원명</th>
          <th>부서</th>
          <th>직책</th>
          <th>연봉</th>
        </tr>
        <tr v-for="(emp, index) in items" :key="index + '_items'" v-if="emp.name.includes(search)">
            <td>{{emp.id}}</td>
            <td>{{emp.name}}</td>
            <td>{{emp.dept}}</td>
            <td>{{emp.title}}</td>
            <td>{{emp.salary}}</td>
        </tr>
      </table>
      <div class="text-right">
        <button class="btn btn-primary" @click="movePage">사원등록</button>
      </div>
    </div>
    <div v-else class="text-center">
        등록된 사원이 존재하지 않습니다.
    </div>
    `,
  data() {
    return {
      items: [],
      search: '',
    };
  },
  created() {
    const emp = localStorage.getItem('emp');

    let newEmp = {
      sequence: 0,
      items: [],
    };

    if (emp) {
      newEmp = JSON.parse(emp);
    } else {
      localStorage.setItem('emp', JSON.stringify(newEmp));
    }

    newEmp.items.sort((a, b) => {
      return -(a.id - b.id);
    });

    this.items = newEmp.items;
  },
  methods: {
    movePage() {
      location.href = './create.html';
    },

    searchEmp(name) {
      console.log(name);
    },
  },
};
