package com.ssafy.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {

	@Autowired 
	ProductService service;
	
	@GetMapping("/listProduct.do") 
	public String productList(Model model) {
		model.addAttribute("list", service.selectAll());
		
		return "product/listProduct";
	}
	
	@GetMapping("/searchProduct.do")
	public String searchProduct(String id, Model model) {
		model.addAttribute("product", service.select(id));
		return "product/searchProduct";
	}
	
	@GetMapping("/insertProductForm.do")
	public String insertProductForm() {
		return "product/insertProduct";
	}
	
	@PostMapping("/insertProduct.do")
	public String insertProduct(Product product) {
		service.insert(product);
		return "redirect:searchProduct.do?id="+product.getId();
	}
	@GetMapping("/updateProductForm.do")
	public String insertProductForm(String id, Model model) {
		System.out.println("Form : " + id);
		model.addAttribute("product", service.select(id));
		return "product/updateProduct";
	}
	
	@PostMapping("/updateProduct.do")
	public String updateProduct(Product product) {
		System.out.println("update : " + product.getId());
		 service.update(product);
		return "redirect:searchProduct.do?id="+product.getId();
	}
	
	@GetMapping("/removeProduct.do")
	public String removeProduct(String id) {
		service.delete(id);
		return "redirect:listProduct.do";
	}
}
