package com.ssafy.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.ssafy.product.vo.Product;

import common.db.ConnectionFactory;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public void insertProduct(Product product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = ConnectionFactory.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into tb_product ( ");
			sql.append("						product_name, ");
			sql.append("						price, ");
			sql.append("						info ");
			sql.append("						) ");
			sql.append("				values ( ");
			sql.append("						?, ");
			sql.append("						?, ");
			sql.append("						? ");
			sql.append("						) ");
			
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, product.getProductName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getInfo());
			pstmt.executeUpdate();
			
		} finally {
			ConnectionFactory.close(pstmt, conn);
		}
	}

}
