package product.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import product.model.productDto;
import product.util.DBUtil;

public class productdaoImpl implements productDao {

	@Override
	public void upProduct(productDto productDto) throws Exception {
		Connection connection = null;
		PreparedStatement pstmt = null;
		try {
			connection = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("insert into hw_product (pcode,pname,price,pdesc)\n");
			sql.append("values (?,?,?,?)");
			pstmt = connection.prepareStatement(sql.toString());
			pstmt.setString(1, productDto.getPcode());
			pstmt.setString(2, productDto.getPname());
			pstmt.setString(3, productDto.getPrice());
			pstmt.setString(4, productDto.getPdesc());
			pstmt.execute();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(connection);
		}
		
	}

	@Override
	public List<productDto> listProduct(String key, String word) throws Exception {
		List<productDto> list = new ArrayList<productDto>();
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			connection = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select pcode,pname,price,pdesc \n");
			sql.append("from hw_product \n");
			pstmt = connection.prepareStatement(sql.toString());
			System.out.println(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				productDto productDto = new productDto();
				productDto.setPcode(rs.getString("pcode"));
				productDto.setPname(rs.getString("pname"));
				productDto.setPrice(rs.getString("price"));
				productDto.setPdesc(rs.getString("pdesc"));
				
				list.add(productDto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(connection);
		}
		return list;
		
	}

}
