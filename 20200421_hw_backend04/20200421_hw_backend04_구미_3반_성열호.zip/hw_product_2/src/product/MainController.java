package product;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import product.model.productDto;
import product.model.service.productService;
import product.model.service.productServiceImpl;


@WebServlet("/main.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private productService productService;
	
   public void init() throws ServletException{
	   super.init();
	   productService = new productServiceImpl();
	   
   }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("process function");
		String root = request.getContextPath();

		String path = "/main.jsp";

		String act = request.getParameter("act");

		if ("mvup".equals(act)) {
			path = "/upProduct.jsp";
			redirect(response, path, root);
		} else if("up".equals(act)) {
			upProduct(request,response);
		} else if("list".equals(act)) {
			showlist(request,response);
		}

	}

	private void showlist(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("list function");
		String path = "/list.jsp";
		String key = "";
		String word = "";
		try {
			List<productDto> list = productService.listProduct(key, word);
			System.out.println(list.size());
			request.setAttribute("products", list);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		forward(request, response, path);
	}


	private void upProduct(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException  {
		System.out.println("upProduct function");
		String root = request.getContextPath();
		String path = "/main.jsp";
		HttpSession session = request.getSession();
		
		productDto productDto = new productDto();
		productDto.setPcode(request.getParameter("pcode"));
		productDto.setPname(request.getParameter("pname"));
		productDto.setPrice(request.getParameter("price"));
		productDto.setPdesc(request.getParameter("pdesc"));
		try {
			productService.upProduct(productDto);
			
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		redirect(response, path, root);
		
	}


	private void forward(HttpServletRequest request, HttpServletResponse response, String path)
			throws ServletException, IOException {
		request.getRequestDispatcher(path).forward(request, response);
	}

	private void redirect(HttpServletResponse response, String path, String root) throws IOException {
		response.sendRedirect(root + path);
	}
}
