package product.model.service;

import java.util.List;

import product.model.productDto;
import product.model.dao.productDao;
import product.model.dao.productdaoImpl;

public class productServiceImpl implements productService {
private productDao productDao;
	public  productServiceImpl() {
		productDao = new productdaoImpl();
	}

	@Override
	public void upProduct(productDto productDto) throws Exception {
		if(productDto.getPcode()== null || productDto.getPname()==null || productDto.getPrice()==null || productDto.getPdesc()==null)
			throw new Exception();
		productDao.upProduct(productDto);
	}

	@Override
	public List<productDto> listProduct(String key, String word) throws Exception {
		return productDao.listProduct(key, word);
	}

}
