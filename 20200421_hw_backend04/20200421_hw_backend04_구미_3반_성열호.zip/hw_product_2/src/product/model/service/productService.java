package product.model.service;

import java.util.List;

import product.model.productDto;

public interface productService {
	public void upProduct(productDto productDto) throws Exception;
	public List<productDto> listProduct(String key,String word) throws Exception;
}
