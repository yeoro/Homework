package com.ssafy.product.dao;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductDao {

	List<Product> selectAll();
	
	Product select(String id);
	
	void insert(Product product);
	
	void update(Product product);
	
	void delete(String id);
}
