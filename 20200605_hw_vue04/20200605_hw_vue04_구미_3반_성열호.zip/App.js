import Create from './components/Create.js';
import List from './components/List.js';
import Index from './components/Index.js';

export default new VueRouter({
    mode: 'history',
    routes: [
        {
            path: '/',
            name: 'index',
            component: Index
        },
        {
            path: '/list',
            name: 'list',
            component: List
        },
        {
            path: '/create',
            name: 'create',
            component: Create
        }
    ]
})