package com.ssafy.test;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

public class BeanTest {

	public static void main(String[] args) {
		
		ProductService service = new ProductServiceImpl();
		List<Product> list = new ArrayList<>();
		
		try {
			
			list = service.selectAll();
			
			for(Product p : list) {
				System.out.println(p.toString());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
