package com.ssafy.product.service;

import com.ssafy.product.vo.MemberDto;

public interface LoginService {

	public MemberDto login(String userid, String userpwd) throws Exception;
	
}
