package com.ssafy.product.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.product.service.LoginService;
import com.ssafy.product.service.LoginServiceImpl;
import com.ssafy.product.vo.MemberDto;

// Context Root 패스는 자동 추가되므로 적으면 안됨
@WebServlet("/main.do")
public class MainController extends HttpServlet{
	private static final long serialVersionUID = 1L;

	private LoginService loginService;
	   
	public void init() {
		  loginService = new LoginServiceImpl();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	         throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	         throws ServletException, IOException {
	    request.setCharacterEncoding("utf-8");
	    process(request, response);
	}
	
	public void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String root = request.getContextPath();

	    String act = request.getParameter("act");

	    if ("mvjoin".equals(act)) {
	    	response.sendRedirect(root + "/user/join.jsp");
	    } else if ("login".equals(act)) {
	    	login(request, response);
	    } else if ("regist".equals(act)) {
	    	
	    } else if ("".equals(act)) {

	    } else if ("".equals(act)) {

	    } else if ("".equals(act)) {

	    } else if ("".equals(act)) {

	    } else if ("".equals(act)) {

	    } else {

	    }
		
	}
	
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");

		try {
			MemberDto memberDto = loginService.login(userid, userpwd);
			if (memberDto != null) { // 로그인 성공
				///////// session /////////
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				//////////////////////////
				//		        path = "/index.jsp";
			} else { // 로그인 실패
				request.setAttribute("msg", "아이디 또는 비밀번호를 확인해 주세요");
				//		        path = "/index.jsp";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void registProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		String info = request.getParameter("info");
		
		StringBuilder html = new StringBuilder();
		
		html.append("<!DOCTYPE html>");
		html.append("<html>");
		html.append("	<head>");
		html.append("		<title> 상품 정보 출력 </title");
		html.append("		<meta charset='utf-8'>");
		html.append("	</head>");
		html.append("	<body>");
		html.append("		<div>");
		html.append("			<h2> 상품명 : " + name + "</h2>");
		html.append("		</div>");
		html.append("		<div>");
		html.append("			<h2> 상품 가격 : " + price + "원</h2>");
		html.append("		</div>");
		html.append("		<div>");
		html.append("			<h2> 상품 설명 : " + info + "</h2>");
		html.append("		</div>");
		html.append("		<div>");
		html.append("			<a href='regist.html'> 상품 등록 </a>");
		html.append("		</div>");
		html.append("	</body>");
		html.append("</html>");
		
		// 브라우저에게 전송하는 컨텐트의 내용을 해석할 수 있게 해야함 -> MIME 타입 설정
		response.setContentType("text/html;charset=utf-8");
//		response.setContentType("text/xml;charset=utf-8");
//		response.setContentType("text/plain;charset=utf-8");
		
		// 모든 처리가 되었으면 response
		// 응답 객체 얻기 (이미지 - 바이트 처리)
//		OutputStream out = response.getOutputStream();
		
		// 응답 객체 얻기 (문자열 처리)
		PrintWriter out = response.getWriter();
		out.println(html.toString());
		out.close();
	}
}
