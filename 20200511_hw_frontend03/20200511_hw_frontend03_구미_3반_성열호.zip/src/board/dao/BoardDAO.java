package board.dao;

import java.util.List;

import board.vo.Board;

public interface BoardDAO {
	
	List<Board> selectBoard() throws Exception;

	Board selectBoardByNo(int no) throws Exception;
	
	void writeBoard(Board board) throws Exception;
	
	void deleteBoard(int no) throws Exception;
}
