package com.ssafy.product.service;

import java.util.List;

import com.ssafy.product.dto.Product;

public interface ProductService {

	List<Product> selectAll();
	
	Product select(String id);
	
	void insert(Product product);
	
	void update(Product product);
	
	void delete(String id);
}

