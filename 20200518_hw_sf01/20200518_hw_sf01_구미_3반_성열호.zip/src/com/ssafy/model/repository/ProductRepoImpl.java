package com.ssafy.model.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ssafy.model.dto.Product;
import com.ssafy.util.DBUtil;

@Repository("productRepository")
public class ProductRepoImpl implements ProductRepo{

	@Override
	public List<Product> selectAll() throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<Product> list = new ArrayList<Product>();
		System.out.println("repo");
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT * FROM product_hw \n");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				
				list.add(product);
			}
		} finally {
			rs.close();
			DBUtil.close(pstmt, conn);
		}
		return list;
	}

	@Override
	public Product select(String id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT id, name, price, description FROM product_hw \n");
			sql.append("WHERE id = ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setId(rs.getString("id"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				
				return product;
			}
		} finally {
			rs.close();
			DBUtil.close(pstmt, conn);
		}
		return null;
	}

	@Override
	public int insert(Product product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("INSERT into product_hw (id, name, price, description) \n");
			sql.append("values ( ?, ?, ?, ? ) \n");
			pstmt = conn.prepareStatement(sql.toString());
			
			int idx = 1;
			pstmt.setString(idx++, product.getId());
			pstmt.setString(idx++, product.getName());
			pstmt.setInt(idx++, product.getPrice());
			pstmt.setString(idx++, product.getDescription());
			
			pstmt.executeUpdate();
			
			return 1;
			
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

	@Override
	public int update(Product product) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("UPDATE product_hw \n");
			sql.append("SET	name = ? \n");
			sql.append("	price = ? \n");
			sql.append("	description = ? \n");
			sql.append("WHERE id = ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			
			int idx = 1;
			pstmt.setString(idx++, product.getName());
			pstmt.setInt(idx++, product.getPrice() );
			pstmt.setString(idx++, product.getDescription());
			pstmt.setString(idx++, product.getId());
			pstmt.executeUpdate();
			
			return 1;
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

	@Override
	public int delete(String id) throws Exception {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("DELETE from product_hw \n");
			sql.append("WHERE id = ? \n");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.executeUpdate();
			
			return 1;
			
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}

}
