package com.ssafy.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.product.dao.ProductDao;
import com.ssafy.product.dao.ProductDaoImpl;
import com.ssafy.product.dto.Product;

@Service("productService")
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductDao dao;
	
	public List<Product> selectAll(){
		return dao.selectAll();
	}

	public Product select(String id){
		return dao.select(id);
	}

	public int insert(Product product){
		return dao.insert(product);
	}

	public int update(Product product){
		return dao.update(product);
	}

	public int delete(String id){
		return dao.delete(id);
	}

}
