<template>
  <div>
    삭제중...
  </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'Delete',
    created() {
      const params = (new URL(document.location)).searchParams;
      axios
      .delete(`http://localhost:8097/hrmboot/api/employee/${params.get('id')}`)
      .then(() => {
        alert("삭제가 완료되었습니다.");
      })
      .catch((error) => {
        console.dir(error);
      })
      .finally(() => {
        this.$router.push('/list');
      });
    }
};
</script>

<style></style>
