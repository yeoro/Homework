package com.ssafy.product.dao;

import java.sql.SQLException;

import com.ssafy.product.vo.MemberDto;

public interface LoginDao {

	public MemberDto login(String userid, String userpwd) throws Exception;
	
}
