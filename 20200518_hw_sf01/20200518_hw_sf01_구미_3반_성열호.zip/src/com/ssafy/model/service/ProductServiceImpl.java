package com.ssafy.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;
import com.ssafy.model.repository.ProductRepoImpl;

@Service("productService")
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepo productRepo;
	
	public ProductServiceImpl() {
		productRepo = new ProductRepoImpl();
	}
	
	@Override
	public List<Product> selectAll() throws Exception{
		System.out.println("service");
		return productRepo.selectAll();
	}

	@Override
	public Product select(String id) throws Exception{
		System.out.println(id);
		return productRepo.select(id);
	}

	@Override
	public int insert(Product product) throws Exception{
		return productRepo.insert(product);
	}

	@Override
	public int update(Product product) throws Exception{
		return productRepo.update(product);
	}

	@Override
	public int delete(String id) throws Exception{
		return productRepo.delete(id);
	}

}
