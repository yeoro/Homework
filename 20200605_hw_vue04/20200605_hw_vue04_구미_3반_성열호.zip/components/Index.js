export default {
    template: `
        <div>
            <div>
                <h1 class="text-center">메인 페이지</h1>
            </div>
            <div>
                만든이 : Yeoro
            </div>
        </div>
    `
};